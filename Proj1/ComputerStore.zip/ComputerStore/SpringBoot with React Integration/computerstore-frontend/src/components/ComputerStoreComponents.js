import React from 'react';
import computerStoreComponents from '../services/ComputerStoreServices';
import { Table,Navbar } from 'react-bootstrap';
class ComputerStoreComponents extends React.Component {

    constructor(props) {
        super(props)
        this.state = {
            tables: []
        }
    }
    componentDidMount() {
        computerStoreComponents.getLaptops().then((Response) => {
            this.setState({ tables: Response.data })
        });
    }

    render() {
        return (
            <div>
                <Navbar bg = "primary">
                    <Navbar.Brand href="#home">Laptops in Computer store</Navbar.Brand>
                    <Navbar.Toggle />
                    <Navbar.Collapse className="justify-content-end">
                    </Navbar.Collapse>
                </Navbar>
                <Table striped bordered hover variant="light">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Laptop Model</th>
                            <th>Laptop Color</th>
                            <th>Laptop Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            this.state.tables.map(
                                table =>
                                    <tr key={table.id}>
                                        <td>{table.id}</td>
                                        <td>{table.modelName}</td>
                                        <td>{table.colour}</td>
                                        <td>{table.price}</td>
                                    </tr>
                            )
                        }
                    </tbody>
                </Table>
            </div>
        )
    }
}
export default ComputerStoreComponents