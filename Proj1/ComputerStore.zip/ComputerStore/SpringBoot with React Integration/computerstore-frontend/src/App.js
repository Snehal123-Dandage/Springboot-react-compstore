import './App.css';
import ComputerStoreComponents from './components/ComputerStoreComponents';

function App() {
  return (
    <div className="App">
          <ComputerStoreComponents/> 
    </div>
  );
}

export default App;
