package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "computerstore")
public class ComputerStore {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	private String modelName;
	private String colour;
	private String price;
	
	
	
	public ComputerStore(String modelName, String colour, String price) {
		super();
		this.modelName = modelName;
		this.colour = colour;
		this.price = price;
	}

	
	public ComputerStore() {
		super();
	}


	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	public String getColour() {
		return colour;
	}
	public void setColour(String colour) {
		this.colour = colour;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	

}
