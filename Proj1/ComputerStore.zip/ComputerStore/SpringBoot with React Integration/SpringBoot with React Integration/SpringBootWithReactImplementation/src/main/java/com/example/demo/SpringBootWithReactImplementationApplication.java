package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo.dao.ComputerStoreRepository;
import com.example.demo.model.ComputerStore;

@SpringBootApplication
public class SpringBootWithReactImplementationApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootWithReactImplementationApplication.class, args);
	}
	@Autowired
	ComputerStoreRepository storeRepository;
	
	@Override
	public void run(String...args) throws Exception{
		 storeRepository.save(new ComputerStore("HP","White","30000"));
		 storeRepository.save(new ComputerStore("DELL","Black","20000"));
		 storeRepository.save(new ComputerStore("LENOVO","Grey","40000"));
		 storeRepository.save(new ComputerStore("APPLE","White","90000"));
	}

}
